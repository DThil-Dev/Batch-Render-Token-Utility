bl_info = {
    "name": "Batch Render Token Utility",
    "author": "DT",
    "version": (1, 8),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Render Batch",
    "description": "Batch add scene tokens and queue multiple scenes for rendering.",
    "category": "Render",
}

if "bpy" in locals():
    import importlib
    if "render_core" in locals():
        importlib.reload(render_core)

import bpy
from . import render_core

def register():
    render_core.register()

def unregister():
    render_core.unregister()
