bl_info = {
    "name": "Batch Render Token Utility",
    "author": "DT",
    "version": (1, 8),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Render Batch",
    "description": "Batch add scene tokens and queue multiple scenes for rendering.",
    "category": "Render",
}

if "bpy" in locals():
    import importlib
    if "core" in locals():
        importlib.reload(core)

import bpy
from . import core

def register():
    core.register()

def unregister():
    core.unregister()
