import sys, subprocess, os

blender_exec = sys.argv[1]
filepath = sys.argv[2]
scenes_arg = sys.argv[3]
cmd_list = sys.argv[4:]

print("\n")
print("n/a")
print("\n")

# Output scenes and engines
engine_script = "import bpy; print(';;;' + ','.join([s.name + ':' + s.render.engine for s in bpy.data.scenes]))"
p_en = subprocess.Popen([blender_exec, "-b", "--factory-startup", filepath, "--python-expr", engine_script], stdout=subprocess.PIPE, text=True)
out_en, _ = p_en.communicate()

engine_map = {}
for line in out_en.splitlines():
    if line.startswith(';;;'):
        req = line[3:].split(',')
        for r in req:
            if ':' in r:
                sn, en = r.split(':', 1)
                engine_map[sn] = en

total_frames_query = "import bpy; print(';;;' + ','.join([s.name + ':' + str(s.frame_end - s.frame_start + 1) for s in bpy.data.scenes]))"
p_fr = subprocess.Popen([blender_exec, "-b", "--factory-startup", filepath, "--python-expr", total_frames_query], stdout=subprocess.PIPE, text=True)
out_fr, _ = p_fr.communicate()
frame_map = {}
for line in out_fr.splitlines():
    if line.startswith(';;;'):
        for r in line[3:].split(','):
            if ':' in r:
                sn, frames = r.split(':', 1)
                frame_map[sn] = int(frames)

scenes = [s for s in scenes_arg.split(',') if s]
for s in scenes:
    print(f"{s} - {engine_map.get(s, 'BLENDER_EEVEE').lower().replace('blender_eevee', 'eevee')}")

print("\n")

current_scene = None
frames_done = 0

p = subprocess.Popen(cmd_list, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
for line in p.stdout:
    print(line.strip())

print("\nRender for all scenes completed.")
