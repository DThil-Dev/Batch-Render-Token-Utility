import bpy
import json
import os
import subprocess
import sys
import shlex
import tempfile
import shutil
from bpy.props import StringProperty, BoolProperty, IntProperty, EnumProperty

TOKEN = "/[scene]/"
VARIANTS = ("\\[scene]\\", "[scene]\\", "/[scene]/", "[scene]/")

_is_loading_profiles = False

# -----------------------------------------------------------------------------
# TIMER RENDER SYSTEM
# -----------------------------------------------------------------------------

_batch_render_queue = []
_batch_render_running = False
_batch_render_animation = False


def batch_render_next_scene():
    global _batch_render_queue
    global _batch_render_running
    global _batch_render_animation

    if not _batch_render_queue:
        _batch_render_running = False
        print("Batch Render Utility: Queue complete.")
        return None

    scene_name = _batch_render_queue.pop(0)

    if scene_name not in bpy.data.scenes:
        return 0.5

    scene = bpy.data.scenes[scene_name]
    bpy.context.window.scene = scene

    print(f"Batch Render Utility: Rendering scene '{scene.name}'")

    try:
        if _batch_render_animation:
            bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
        else:
            bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)
    except Exception as e:
        print(f"Batch Render Utility Error: {e}")

    return 1.0


def load_profiles_from_disk(wm):
    global _is_loading_profiles
    _is_loading_profiles = True

    addon_dir = os.path.dirname(os.path.abspath(__file__))
    profiles_file = os.path.join(addon_dir, "output_profiles.json")
    
    wm.batch_output_profiles.clear()
    
    if os.path.exists(profiles_file):
        try:
            with open(profiles_file, 'r') as f:
                data = json.load(f)
                
            if isinstance(data, list):
                for item in data:
                    p = wm.batch_output_profiles.add()
                    p.name = item.get("name", "Unnamed Profile")
                    p.settings_json = item.get("settings_json", "{}")
        except Exception as e:
            print(f"Batch Render Utility: Failed to load profiles from single file: {e}")

    cmd_file = os.path.join(addon_dir, "command_line.json")
    if os.path.exists(cmd_file):
        try:
            with open(cmd_file, 'r') as f:
                data = json.load(f)
                wm.batch_render_output_path = data.get("path", "")
        except Exception as e:
            pass

    _is_loading_profiles = False

def save_profiles_to_disk(wm):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    profiles_file = os.path.join(addon_dir, "output_profiles.json")
    
    data = []
    for p in wm.batch_output_profiles:
        data.append({
            "name": p.name,
            "settings_json": p.settings_json
        })
        
    try:
        with open(profiles_file, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Batch Render Utility: Failed to save profiles to single file: {e}")

def save_command_line_path(self, context):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    cmd_file = os.path.join(addon_dir, "command_line.json")
    data = {"path": self.batch_render_output_path}
    try:
        with open(cmd_file, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception:
        pass

def update_profile_name(self, context):
    global _is_loading_profiles
    if _is_loading_profiles: return
    if hasattr(context, "window_manager"):
        save_profiles_to_disk(context.window_manager)

class RENDER_OT_batch_add_token(bpy.types.Operator):
    bl_idname = "render.batch_add_token"
    bl_label = "Add to All"
    bl_description = "Append scene token subdirectories to ALL paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        count = 0
        for scene in bpy.data.scenes:
            path = scene.render.filepath
            if not any(path.endswith(v) for v in VARIANTS):
                base_path = path.rstrip("\\/")
                scene.render.filepath = f"{base_path}{TOKEN}"
                count += 1
        self.report({'INFO'}, f"Added tokens to {count} scene(s)")
        return {'FINISHED'}

class RENDER_OT_batch_remove_token(bpy.types.Operator):
    bl_idname = "render.batch_remove_token"
    bl_label = "Remove from All"
    bl_description = "Strip scene token subdirectories from ALL paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        count = 0
        for scene in bpy.data.scenes:
            path = scene.render.filepath
            for variant in VARIANTS:
                if path.endswith(variant):
                    scene.render.filepath = path[:-len(variant)]
                    count += 1
                    break
        self.report({'INFO'}, f"Reverted paths for {count} scene(s)")
        return {'FINISHED'}

class RENDER_OT_toggle_scene_token(bpy.types.Operator):
    bl_idname = "render.toggle_scene_token"
    bl_label = "Toggle Token"
    bl_description = "Add or remove the token for this specific scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    scene_name: StringProperty()
    
    def execute(self, context):
        if self.scene_name not in bpy.data.scenes:
            return {'CANCELLED'}
            
        scene = bpy.data.scenes[self.scene_name]
        path = scene.render.filepath
        has_token = False
        
        for variant in VARIANTS:
            if path.endswith(variant):
                scene.render.filepath = path[:-len(variant)]
                has_token = True
                break
        
        if not has_token:
            base_path = path.rstrip("\\/")
            scene.render.filepath = f"{base_path}{TOKEN}"
            
        return {'FINISHED'}

class RENDER_OT_execute_batch_queue(bpy.types.Operator):
    bl_idname = "render.execute_batch_queue"
    bl_label = "Render Selected"
    bl_description = "Render all checked scenes"

    is_animation: BoolProperty(default=False)

    def execute(self, context):
        wm = context.window_manager
        render_mode = wm.batch_render_mode

        queued_scenes = [s for s in bpy.data.scenes if s.batch_token_queue]

        if len(queued_scenes) == 0 and render_mode != 'PROJECT':
            self.report({'WARNING'}, "No scenes queued for rendering!")
            return {'CANCELLED'}

        # -----------------------------------------------------------------
        # SINGLE SCENE = DIRECT RENDER
        # -----------------------------------------------------------------

        if len(queued_scenes) == 1 and render_mode != 'PROJECT':
            scene = queued_scenes[0]
            context.window.scene = scene

            self.report({'INFO'}, f"Rendering single scene: {scene.name}")

            if self.is_animation:
                bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
            else:
                bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)

            return {'FINISHED'}

        # -----------------------------------------------------------------
        # COMMAND LINE & PROJECT MODE
        # -----------------------------------------------------------------

        if render_mode in ['COMMAND_LINE', 'PROJECT']:

            if not bpy.data.is_saved:
                self.report({'ERROR'}, "Please save your blend file first.")
                return {'CANCELLED'}

            bpy.ops.wm.save_mainfile()

            blender_exec = bpy.app.binary_path
            filepath = bpy.data.filepath

            cmds = []
            scenes_str = ",".join(s.name for s in queued_scenes)

            if render_mode == 'COMMAND_LINE':
                cmd = [blender_exec, "-b", "--factory-startup", filepath]
                for scene in queued_scenes:
                    cmd.extend(["-S", scene.name])
                    if self.is_animation:
                        cmd.append("-a")
                    else:
                        cmd.extend(["-f", str(scene.frame_current)])
                cmds.append(cmd)
            elif render_mode == 'PROJECT':
                cmd = [blender_exec, "-b", "--factory-startup", filepath]
                if self.is_animation:
                    cmd.append("-a")
                else:
                    cmd.extend(["-f", str(context.scene.frame_current)])
                cmds.append(cmd)

            addon_dir = os.path.dirname(os.path.abspath(__file__))
            wrapper_path = os.path.join(addon_dir, "wrapper_template.py")
            
            py_exe = os.path.join(sys.prefix, 'bin', 'python.exe' if sys.platform == 'win32' else 'python3')
            if not os.path.exists(py_exe):
                py_exe = 'python' if sys.platform == 'win32' else 'python3'

            try:
                # WINDOWS
                if sys.platform == 'win32':

                    sound_path = os.path.join(addon_dir, "render_success.ogg")

                    with tempfile.NamedTemporaryFile(mode='w', suffix='.bat', delete=False) as f:
                        f.write("@echo off\n")
                        f.write("echo Batch Render Utility\n")
                        for cmd in cmds:
                            args = [py_exe, wrapper_path, blender_exec, filepath, scenes_str] + cmd
                            cmd_str = subprocess.list2cmdline(args)
                            f.write(f"{cmd_str}\n")
                        f.write(f"powershell -c \"$player = New-Object -ComObject wmplayer.ocx; $player.URL = '{sound_path}'; $player.controls.play(); Start-Sleep -s 5\"\n")
                        f.write("pause\n")
                        bat_path = f.name

                    custom_exe = ""
                    if hasattr(wm, 'batch_render_output_path') and wm.batch_render_output_path:
                        custom_path = bpy.path.abspath(wm.batch_render_output_path).replace('//', '')
                        if custom_path and os.path.exists(custom_path) and os.path.isfile(custom_path):
                            custom_exe = os.path.normpath(custom_path)

                    if custom_exe:
                        subprocess.Popen(['cmd.exe', '/c', 'start', 'Batch Render', custom_exe, '/c', bat_path])
                    else:
                        cmd_exe_path = r"C:\Windows\System32\cmd.exe"
                        
                        if os.path.exists(cmd_exe_path):
                            subprocess.Popen(['cmd.exe', '/c', 'start', 'Batch Render', cmd_exe_path, '/c', bat_path])
                        else:
                            subprocess.Popen([
                                'cmd.exe',
                                '/c',
                                'start',
                                'Batch Render',
                                bat_path
                            ])

                # MACOS
                elif sys.platform == 'darwin':

                    sound_path = os.path.join(addon_dir, "render_success.ogg")

                    with tempfile.NamedTemporaryFile(mode='w', suffix='.command', delete=False) as f:
                        f.write("#!/bin/bash\n")
                        for cmd in cmds:
                            args = [py_exe, wrapper_path, blender_exec, filepath, scenes_str] + cmd
                            cmd_str = ' '.join(shlex.quote(c) for c in args)
                            f.write(f"{cmd_str}\n")
                        f.write(f"afplay {shlex.quote(sound_path)}\n")
                        f.write("echo 'Batch render complete.'\n")
                        f.write("read -p 'Press Enter to close...'\n")
                        script_path = f.name

                    os.chmod(script_path, 0o755)
                    custom_exe = ""
                    if hasattr(wm, 'batch_render_output_path') and wm.batch_render_output_path:
                        custom_path = bpy.path.abspath(wm.batch_render_output_path).replace('//', '')
                        if custom_path and os.path.exists(custom_path) and os.path.isfile(custom_path):
                            custom_exe = custom_path
                            
                    if custom_exe:
                        subprocess.Popen(['open', '-a', custom_exe, script_path])
                    else:
                        subprocess.Popen(['open', script_path])

                # LINUX
                else:

                    sound_path = os.path.join(addon_dir, "render_success.ogg")

                    with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
                        f.write("#!/bin/bash\n")
                        for cmd in cmds:
                            args = [py_exe, wrapper_path, blender_exec, filepath, scenes_str] + cmd
                            cmd_str = ' '.join(shlex.quote(c) for c in args)
                            f.write(f"{cmd_str}\n")
                        f.write(f"test -x /usr/bin/paplay && paplay {shlex.quote(sound_path)} || aplay {shlex.quote(sound_path)}\n")
                        f.write("echo 'Batch render complete.'\n")
                        f.write("read -p 'Press Enter to close...'\n")
                        script_path = f.name

                    os.chmod(script_path, 0o755)

                    terminals = [
                        'x-terminal-emulator',
                        'gnome-terminal',
                        'konsole',
                        'xfce4-terminal'
                    ]

                    term_cmd = None

                    for term in terminals:
                        if shutil.which(term):
                            if term == 'gnome-terminal':
                                term_cmd = [term, '--', 'bash', script_path]
                            else:
                                term_cmd = [term, '-e', script_path]
                            break

                    custom_exe = ""
                    if hasattr(wm, 'batch_render_output_path') and wm.batch_render_output_path:
                        custom_path = bpy.path.abspath(wm.batch_render_output_path).replace('//', '')
                        if custom_path and os.path.exists(custom_path) and os.path.isfile(custom_path):
                            custom_exe = custom_path

                    if custom_exe:
                        subprocess.Popen([custom_exe, '-e', script_path])
                    elif term_cmd:
                        subprocess.Popen(term_cmd)
                    else:
                        subprocess.Popen(['bash', script_path])

                msg = "entire project" if render_mode == 'PROJECT' else f"{len(queued_scenes)} scenes"
                self.report({'INFO'}, f"Started {render_mode} render for {msg}.")

            except Exception as e:
                self.report({'ERROR'}, f"Failed to start render process: {str(e)}")
                return {'CANCELLED'}

            return {'FINISHED'}

        # -----------------------------------------------------------------
        # TIMER MODE
        # -----------------------------------------------------------------

        global _batch_render_queue
        global _batch_render_running
        global _batch_render_animation

        if _batch_render_running:
            self.report({'WARNING'}, "Batch render already running.")
            return {'CANCELLED'}

        _batch_render_queue = [scene.name for scene in queued_scenes]
        _batch_render_animation = self.is_animation
        _batch_render_running = True

        bpy.app.timers.register(batch_render_next_scene, first_interval=0.5)

        self.report({'INFO'}, f"Started timer-based render for {len(queued_scenes)} scenes.")

        return {'FINISHED'}

# --- UIList Class for the Token Menu ---
class RENDER_UL_token_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = item
        row = layout.row(align=True)
        
        split = row.split(factor=0.7)
        split.label(text=scene.name)
        
        row_right = split.row(align=True)
        path = scene.render.filepath
        has_token = any(path.endswith(v) for v in VARIANTS)
        
        if has_token:
            op = row_right.operator("render.toggle_scene_token", text="", icon='X')
        else:
            op = row_right.operator("render.toggle_scene_token", text="", icon='ADD')
            
        op.scene_name = scene.name

# --- UIList Class for the Queue Menu ---
class RENDER_UL_scene_queue_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = item
        row = layout.row(align=True)
        
        # 1. The Checkbox
        row.prop(scene, "batch_token_queue", text="")
        
        # Split layout to allocate space for name vs fields cleanly
        split = row.split(factor=0.4)
        
        # 2. The Scene Name
        split.label(text=scene.name)
        
        # Right side layout
        row_right = split.row(align=True)
        
        # 3. Start & End Frames
        row_right.prop(scene, "frame_start", text="")
        row_right.prop(scene, "frame_end", text="")

# --- PANEL 1: Global Token Assignment ---
class RENDER_PT_token_panel(bpy.types.Panel):
    bl_label = "Batch Render Tokens"
    bl_idname = "RENDER_PT_token_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch' 

    def draw(self, context):
        layout = self.layout
        
        # Global Batch Controls
        box_global = layout.box()
        box_global.label(text="Global Token Assignment:", icon='WORLD')
        row_global = box_global.row(align=True)
        row_global.operator("render.batch_add_token", icon='ADD')
        row_global.operator("render.batch_remove_token", icon='REMOVE')

        layout.separator()
        
        # Individual Scene Token List
        layout.label(text="Scene Tokens:", icon='TEXT')
        layout.template_list(
            "RENDER_UL_token_list", 
            "", 
            bpy.data, 
            "scenes", 
            context.window_manager, 
            "batch_token_list_index"
        )

# --- PANEL 2: Render Queue and Lists ---
class RENDER_PT_queue_panel(bpy.types.Panel):
    bl_label = "Batch Render Queue"
    bl_idname = "RENDER_PT_queue_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch' 
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        # Individual Scene List
        layout.label(text="Scene Queue:", icon='VIEW_CAMERA')
        
        # The scrollable list rendering
        layout.template_list(
            "RENDER_UL_scene_queue_list", 
            "", 
            bpy.data, 
            "scenes", 
            context.window_manager, 
            "batch_list_index"
        )
            
        layout.separator()
        
        # -----------------------------------------------------------------
        # COMMAND LINE OUTPUT BOX
        # -----------------------------------------------------------------
        
        box_out = layout.box()
        box_out.label(text="Command Line Output Path (Executable Shortcut):", icon='FILE_FOLDER')
        box_out.prop(wm, "batch_render_output_path", text="")
        box_out.label(text="Provide a the shortcut for the command prompt executable of Windows/Mac/Linux.", icon='INFO')

        layout.separator()

        # -----------------------------------------------------------------
        # BATCH RENDER MODE
        # -----------------------------------------------------------------

        box_mode = layout.box()
        box_mode.label(text="Batch Render Mode:", icon='PREFERENCES')
        box_mode.prop(wm, "batch_render_mode", expand=True)

        # -----------------------------------------------------------------
        # EXECUTION BUTTONS
        # -----------------------------------------------------------------

        box_mode.separator()
        box_mode.label(text="Execute Render Queue / Project:", icon='RENDER_RESULT')
        row_exec = box_mode.row(align=True)
        
        op_still = row_exec.operator("render.execute_batch_queue", text="Stills", icon='RENDER_STILL')
        op_still.is_animation = False
        
        op_anim = row_exec.operator("render.execute_batch_queue", text="Animations", icon='RENDER_ANIMATION')
        op_anim.is_animation = True

# --- PROFILES AND SETTINGS SYNC ---
class RENDER_PG_output_profile(bpy.types.PropertyGroup):
    name: StringProperty(name="Profile Name", default="New Profile", update=update_profile_name)
    settings_json: StringProperty(name="Settings JSON", default="{}")
    file_id: StringProperty(name="File ID", default="")

class RENDER_UL_output_profile_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "name", text="", emboss=False, icon='PREFERENCES')

class RENDER_OT_profile_add(bpy.types.Operator):
    bl_idname = "render.profile_add"
    bl_label = "Save Output to Profile"
    bl_description = "Save the active scene's output settings as a new profile"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        new_profile = profiles.add()
        new_profile.name = f"Profile {len(profiles)}"
        import uuid
        new_profile.file_id = str(uuid.uuid4()) + ".json"
        
        dump = {}
        r = scene.render

        # Render dimensions / frame rate
        for k in ['resolution_x', 'resolution_y', 'resolution_percentage', 'fps', 'fps_base']:
            dump[k] = getattr(r, k)

        # Output section: path, saving flags, pixel density
        # These are the settings visible in the Output panel (filepath, File
        # Extensions, Cache Result, Pixel Density) that were previously missing.
        for k in ['filepath', 'use_file_extension', 'use_render_cache', 'dpi']:
            if hasattr(r, k):
                dump[k] = getattr(r, k)

        # Image / format settings
        i = r.image_settings
        if hasattr(i, 'media_type'):
            dump['img_media_type'] = getattr(i, 'media_type')
        elif hasattr(r, 'media_type'):
            dump['media_type'] = getattr(r, 'media_type')

        for k in ['file_format', 'color_mode', 'color_depth', 'compression', 'quality', 'exr_codec', 'tiff_codec']:
            if hasattr(i, k):
                dump['img_' + k] = getattr(i, k)
                
        # FFMpeg settings
        if hasattr(r, 'ffmpeg'):
            ff = r.ffmpeg
            for k in ['format', 'codec', 'video_profile', 'constant_rate_factor', 'audio_codec', 'video_bitrate', 'audio_bitrate']:
                if hasattr(ff, k):
                    dump['ff_' + k] = getattr(ff, k)

        new_profile.settings_json = json.dumps(dump)
        wm.batch_output_profile_index = len(profiles) - 1
        save_profiles_to_disk(wm)
        return {'FINISHED'}

class RENDER_OT_profile_remove(bpy.types.Operator):
    bl_idname = "render.profile_remove"
    bl_label = "Remove Selected Profile"
    bl_description = "Delete the currently selected output profile"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        idx = wm.batch_output_profile_index
        
        if 0 <= idx < len(profiles):
            profiles.remove(idx)
            wm.batch_output_profile_index = max(0, idx - 1)
            save_profiles_to_disk(wm)
        return {'FINISHED'}

def apply_profile_to_scene(profile, target_scene):
    try:
        dump = json.loads(profile.settings_json)
    except Exception:
        return
        
    r = target_scene.render
    i = r.image_settings
    
    if 'img_media_type' in dump and hasattr(i, 'media_type'):
        try: i.media_type = dump['img_media_type']
        except: pass
    if 'media_type' in dump and hasattr(r, 'media_type'):
        try: r.media_type = dump['media_type']
        except: pass

    if 'img_file_format' in dump:
        try:
            i.file_format = dump['img_file_format']
        except Exception as e:
            print(f"Batch Render Utility: Could not set file_format {dump['img_file_format']} - {e}")
            try:
                if hasattr(i, 'media_type'): i.media_type = 'VIDEO'
                elif hasattr(r, 'media_type'): r.media_type = 'VIDEO'
            except: pass
            try: i.file_format = 'FFMPEG'
            except: pass
            try: i.color_mode = 'RGBA'
            except: pass
            if hasattr(r, 'ffmpeg'):
                try: r.ffmpeg.format = 'QUICKTIME'
                except: pass
                try: r.ffmpeg.codec = 'PRORES'
                except: pass
                try: r.ffmpeg.video_profile = '4444'
                except: pass
        
    for k, v in dump.items():
        if k.startswith('img_'):
            prop_name = k[4:]
            if prop_name != 'file_format' and prop_name != 'media_type' and hasattr(i, prop_name):
                try:
                    setattr(i, prop_name, v)
                except Exception:
                    pass
        elif k.startswith('ff_'):
            prop_name = k[3:]
            if hasattr(r, 'ffmpeg') and hasattr(r.ffmpeg, prop_name):
                try:
                    setattr(r.ffmpeg, prop_name, v)
                except Exception:
                    pass
        else:
            if k != 'media_type' and hasattr(r, k):
                try:
                    setattr(r, k, v)
                except Exception:
                    pass

class RENDER_OT_profile_apply(bpy.types.Operator):
    bl_idname = "render.profile_apply"
    bl_label = "Apply to Active Scene"
    bl_description = "Apply the selected profile's output settings to the active scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        idx = wm.batch_output_profile_index
        
        if 0 <= idx < len(profiles):
            apply_profile_to_scene(profiles[idx], scene)
            self.report({'INFO'}, f"Applied profile '{profiles[idx].name}' to {scene.name}")
        return {'FINISHED'}

class RENDER_OT_batch_sync_profile(bpy.types.Operator):
    bl_idname = "render.batch_sync_profile"
    bl_label = "Batch Sync Profile to ALL Scenes"
    bl_description = "Apply the selected profile's output settings to ALL scenes in the file"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        idx = wm.batch_output_profile_index
        
        if 0 <= idx < len(profiles):
            profile = profiles[idx]
            count = 0
            for s in bpy.data.scenes:
                apply_profile_to_scene(profile, s)
                count += 1
            self.report({'INFO'}, f"Applied profile '{profile.name}' to {count} scene(s)")
        return {'FINISHED'}

class RENDER_OT_batch_sync_active(bpy.types.Operator):
    bl_idname = "render.batch_sync_active"
    bl_label = "Sync Active to ALL Scenes"
    bl_description = "Copy the active scene's output settings to ALL scenes in the file"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        
        dump = {}
        r = scene.render
        for k in ['resolution_x', 'resolution_y', 'resolution_percentage', 'fps', 'fps_base']:
            dump[k] = getattr(r, k)

        # Output section: path, saving flags, pixel density
        for k in ['filepath', 'use_file_extension', 'use_render_cache', 'dpi']:
            if hasattr(r, k):
                dump[k] = getattr(r, k)

        i = r.image_settings
        if hasattr(i, 'media_type'):
            dump['img_media_type'] = getattr(i, 'media_type')
        elif hasattr(r, 'media_type'):
            dump['media_type'] = getattr(r, 'media_type')

        for k in ['file_format', 'color_mode', 'color_depth', 'compression', 'quality', 'exr_codec', 'tiff_codec']:
            if hasattr(i, k):
                dump['img_' + k] = getattr(i, k)
                
        if hasattr(r, 'ffmpeg'):
            ff = r.ffmpeg
            for k in ['format', 'codec', 'video_profile', 'constant_rate_factor', 'audio_codec', 'video_bitrate', 'audio_bitrate']:
                if hasattr(ff, k):
                    dump['ff_' + k] = getattr(ff, k)

        count = 0
        for s in bpy.data.scenes:
            if s == scene:
                continue
            
            tr = s.render
            ti = tr.image_settings
            
            if 'img_media_type' in dump and hasattr(ti, 'media_type'):
                try: ti.media_type = dump['img_media_type']
                except: pass
            if 'media_type' in dump and hasattr(tr, 'media_type'):
                try: tr.media_type = dump['media_type']
                except: pass

            if 'img_file_format' in dump:
                try:
                    ti.file_format = dump['img_file_format']
                except Exception as e:
                    print(f"Batch Render Utility: Could not set file_format {dump['img_file_format']} - {e}")
                    try:
                        if hasattr(ti, 'media_type'): ti.media_type = 'VIDEO'
                        elif hasattr(tr, 'media_type'): tr.media_type = 'VIDEO'
                    except: pass
                    try: ti.file_format = 'FFMPEG'
                    except: pass
                    try: ti.color_mode = 'RGBA'
                    except: pass
                    if hasattr(tr, 'ffmpeg'):
                        try: tr.ffmpeg.format = 'QUICKTIME'
                        except: pass
                        try: tr.ffmpeg.codec = 'PRORES'
                        except: pass
                        try: tr.ffmpeg.video_profile = '4444'
                        except: pass
                
            for k, v in dump.items():
                if k.startswith('img_'):
                    prop_name = k[4:]
                    if prop_name != 'file_format' and prop_name != 'media_type' and hasattr(ti, prop_name):
                        try:
                            setattr(ti, prop_name, v)
                        except Exception:
                            pass
                elif k.startswith('ff_'):
                    prop_name = k[3:]
                    if hasattr(tr, 'ffmpeg') and hasattr(tr.ffmpeg, prop_name):
                        try:
                            setattr(tr.ffmpeg, prop_name, v)
                        except Exception:
                            pass
                else:
                    if k != 'media_type' and hasattr(tr, k):
                        try:
                            setattr(tr, k, v)
                        except Exception:
                            pass
            count += 1
            
        self.report({'INFO'}, f"Synced output settings to {count} other scene(s)")
        return {'FINISHED'}

class RENDER_PT_sync_settings_panel(bpy.types.Panel):
    bl_label = "Batch Sync Output"
    bl_idname = "RENDER_PT_sync_settings_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch'
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        # 1. Sync Active to All
        layout.label(text="Sync Current Settings:", icon='FILE_REFRESH')
        layout.operator("render.batch_sync_active", icon='SCENE_DATA')

class RENDER_PT_sync_settings_profiles_panel(bpy.types.Panel):
    bl_label = "Output Profiles (WIP)"
    bl_idname = "RENDER_PT_sync_settings_profiles_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch'
    bl_parent_id = "RENDER_PT_sync_settings_panel"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        row = layout.row()
        row.template_list(
            "RENDER_UL_output_profile_list", 
            "", 
            wm, 
            "batch_output_profiles", 
            wm, 
            "batch_output_profile_index",
            rows=3
        )
        
        col = row.column(align=True)
        col.operator("render.profile_add", text="", icon='ADD')
        col.operator("render.profile_remove", text="", icon='REMOVE')
        
        if len(wm.batch_output_profiles) > 0:
            box = layout.box()
            box.label(text="Apply Selected Profile:", icon='CHECKBOX_HLT')
            box.operator("render.profile_apply", text="Apply to Active Scene", icon='SCENE_DATA')
            box.operator("render.batch_sync_profile", text="Sync to ALL Scenes", icon='MODIFIER_ON')

classes = (
    RENDER_OT_batch_add_token,
    RENDER_OT_batch_remove_token,
    RENDER_OT_toggle_scene_token,
    RENDER_OT_execute_batch_queue,
    RENDER_UL_token_list,
    RENDER_UL_scene_queue_list,
    RENDER_PT_token_panel,
    RENDER_PT_queue_panel,
    RENDER_PG_output_profile,
    RENDER_UL_output_profile_list,
    RENDER_OT_profile_add,
    RENDER_OT_profile_remove,
    RENDER_OT_profile_apply,
    RENDER_OT_batch_sync_profile,
    RENDER_OT_batch_sync_active,
    RENDER_PT_sync_settings_panel,
    RENDER_PT_sync_settings_profiles_panel,
)

def init_profiles():
    if hasattr(bpy.context, "window_manager") and bpy.context.window_manager:
        load_profiles_from_disk(bpy.context.window_manager)
    return None

@bpy.app.handlers.persistent
def on_blend_load(dummy):
    if not bpy.app.timers.is_registered(init_profiles):
        bpy.app.timers.register(init_profiles, first_interval=0.1)

def update_scene_index(self, context):
    try:
        idx = self.batch_list_index
        if 0 <= idx < len(bpy.data.scenes):
            tgt_scene = bpy.data.scenes[idx]
            if context.window.scene != tgt_scene:
                context.window.scene = tgt_scene
    except Exception:
        pass

def update_scene_token_index(self, context):
    try:
        idx = self.batch_token_list_index
        if 0 <= idx < len(bpy.data.scenes):
            tgt_scene = bpy.data.scenes[idx]
            if context.window.scene != tgt_scene:
                context.window.scene = tgt_scene
    except Exception:
        pass

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
    if on_blend_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(on_blend_load)
    if not bpy.app.timers.is_registered(init_profiles):
        bpy.app.timers.register(init_profiles, first_interval=0.1)

    # Scene properties
    bpy.types.Scene.batch_token_queue = bpy.props.BoolProperty(
        name="Queue",
        description="Include this scene in the batch render execution",
        default=False
    )
    
    # UI List tracking properties
    bpy.types.WindowManager.batch_list_index = bpy.props.IntProperty(
        name="Active List Index", 
        default=0,
        update=update_scene_index
    )
    bpy.types.WindowManager.batch_token_list_index = bpy.props.IntProperty(
        name="Active Token List Index", 
        default=0,
        update=update_scene_token_index
    )
    bpy.types.WindowManager.batch_output_profiles = bpy.props.CollectionProperty(type=RENDER_PG_output_profile)
    bpy.types.WindowManager.batch_output_profile_index = bpy.props.IntProperty(name="Active Profile Index", default=0)

    # -----------------------------------------------------------------
    # COMMAND LINE OUTPUT BOX
    # -----------------------------------------------------------------
    bpy.types.WindowManager.batch_render_output_path = bpy.props.StringProperty(
        name="Terminal Executable Shortcut",
        description="Provide the shortcut for the command prompt executable. Leave empty to use system default",
        subtype='FILE_PATH',
        default="",
        update=save_command_line_path
    )

    # -----------------------------------------------------------------
    # RENDER MODE TOGGLE
    # -----------------------------------------------------------------
    bpy.types.WindowManager.batch_render_mode = bpy.props.EnumProperty(
        name="Render Mode",
        description="Choose how the batch queue should render",
        items=[
            ('COMMAND_LINE', 'Command Line', 'Render via Background Process'),
            ('TIMER', 'Timer Based', 'Render inside Blender'),
            ('PROJECT', 'Project', 'Render the entire blend file')
        ],
        default='COMMAND_LINE'
    )

def unregister():
    if on_blend_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(on_blend_load)
    if bpy.app.timers.is_registered(init_profiles):
        bpy.app.timers.unregister(init_profiles)

    # Clean up properties
    del bpy.types.Scene.batch_token_queue
    del bpy.types.WindowManager.batch_list_index
    del bpy.types.WindowManager.batch_token_list_index
    del bpy.types.WindowManager.batch_output_profiles
    del bpy.types.WindowManager.batch_output_profile_index
    del bpy.types.WindowManager.batch_render_output_path
    del bpy.types.WindowManager.batch_render_mode
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
