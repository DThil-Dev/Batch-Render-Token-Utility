import bpy
import json
import os
import subprocess
import sys
import shlex
import tempfile
import shutil
from bpy.props import StringProperty, BoolProperty, IntProperty, EnumProperty




TOKEN = "/[scene]/"
VARIANTS = ("\\\\[scene]\\\\", "[scene]\\\\", "/[scene]/", "[scene]/")

class State:
    is_loading_profiles = False
    batch_render_queue = []
    batch_render_running = False
    batch_render_animation = False

# -----------------------------------------------------------------------------
# PROJECT RENDER SYSTEM
# -----------------------------------------------------------------------------





@bpy.app.handlers.persistent
def batch_render_complete_handler(scene):
            
    if State.batch_render_running:
        try:
            import os, shutil, re, glob
            if '#' not in scene.render.filepath:
                wanted_fp = bpy.path.abspath(scene.render.filepath)
                if not (wanted_fp.endswith('/') or wanted_fp.endswith('\\')):
                    is_movie = scene.render.image_settings.file_format in {'FFMPEG', 'AVI_JPEG', 'AVI_RAW'}
                    # Do not rename if it's an animation but NOT a movie (this is an image sequence)
                    if not (State.batch_render_animation and not is_movie):
                        ext = scene.render.file_extension
                        final_dest = wanted_fp if wanted_fp.endswith(ext) else wanted_fp + ext
                        search_pattern = wanted_fp + '*' + ext
                        written = None
                        for m in glob.glob(search_pattern):
                            if re.match('^' + re.escape(wanted_fp) + r'\d*(-\d+)?' + re.escape(ext) + '$', m):
                                written = m
                                break
                        if written and os.path.exists(written) and os.path.abspath(written) != os.path.abspath(final_dest):
                            if os.path.exists(final_dest):
                                try: os.remove(final_dest)
                                except: pass
                            try: shutil.move(written, final_dest)
                            except Exception as e:
                                print(f"Failed to move {written} to {final_dest}: {e}")
        except Exception as e:
            print(f"Batch Render Rename Error: {e}")

    if "_original_filepath" in scene:
        scene.render.filepath = scene["_original_filepath"]
        del scene["_original_filepath"]
    if State.batch_render_running:
        bpy.app.timers.register(batch_render_next_scene, first_interval=0.5)

@bpy.app.handlers.persistent
def batch_render_cancel_handler(scene):
    if "_original_filepath" in scene:
        scene.render.filepath = scene["_original_filepath"]
        del scene["_original_filepath"]
    if State.batch_render_running:
        State.batch_render_running = False
        State.batch_render_queue.clear()
        print("Batch Render Utility: Queue cancelled.")

def batch_render_next_scene():
    if not State.batch_render_queue:
        State.batch_render_running = False
        print("Batch Render Utility: Queue complete.")
        def show_msg():
            try:
                bpy.ops.render.batch_notify_msg('INVOKE_DEFAULT', message="Batch Render Project Completed!")
            except Exception:
                pass
            return None
        bpy.app.timers.register(show_msg, first_interval=0.1)
        return None

    scene_name = State.batch_render_queue.pop(0)

    if scene_name not in bpy.data.scenes:
        bpy.app.timers.register(batch_render_next_scene, first_interval=0.1)
        return None

    scene = bpy.data.scenes[scene_name]
    
    op = scene.render.filepath
    import datetime, uuid
    
    if any(token in op for token in ["{{scene}}", "{{camera}}", "{{date}}", "{{frame_range}}"]):
        scene["_original_filepath"] = op
        t = op.replace("{{scene}}", scene.name)
        if "{{camera}}" in t:
            t = t.replace("{{camera}}", scene.camera.name if scene.camera else "NoCamera")
        if "{{date}}" in t:
            t = t.replace("{{date}}", datetime.datetime.now().strftime("%d%m%y"))
        if "{{frame_range}}" in t:
            t = t.replace("{{frame_range}}", f"{scene.frame_start}-{scene.frame_end}")
        scene.render.filepath = t

    if any(token in op for token in ["[s]", "[d]", "[c]", "[f]", "[e]"]):
        if "_original_filepath" not in scene:
            scene["_original_filepath"] = op
        t = op.replace("[f]", scene.name + "/").replace("[s]", scene.name)
        t = t.replace("[c]", scene.camera.name if scene.camera else "NoCamera")
        t = t.replace("[d]", datetime.datetime.now().strftime("%d%m%y"))
        t = t.replace("[e]", "")
        scene.render.filepath = t

    try:
        if bpy.context.window:
            bpy.context.window.scene = scene
    except:
        pass

    print(f"Batch Render Utility: Rendering scene '{scene.name}'")

    try:
        if State.batch_render_running:
            bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
        else:
            bpy.ops.render.render('INVOKE_DEFAULT', write_still=True)
    except Exception as e:
        print(f"Batch Render Utility Error: {e}")
        def show_err():
            try:
                bpy.ops.render.batch_notify_msg('INVOKE_DEFAULT', message=f"Render failed ({scene.name}): {str(e)}", level="ERROR")
            except Exception:
                pass
            return None
        bpy.app.timers.register(show_err, first_interval=0.1)
        bpy.app.timers.register(batch_render_next_scene, first_interval=1.0)

    return None


def load_profiles_from_disk(wm):
    State.is_loading_profiles = True

    addon_dir = os.path.dirname(os.path.abspath(__file__))
    profiles_file = os.path.join(addon_dir, "json/output_profiles.json")
    
    wm.batch_output_profiles.clear()
    
    if os.path.exists(profiles_file):
        try:
            with open(profiles_file, 'r') as f:
                data = json.load(f)
                
            if isinstance(data, list):
                for item in data:
                    p = wm.batch_output_profiles.add()
                    p.name = item.get("name", "Unnamed Profile")
                    p.settings_json = item.get("settings_json", "{}")
        except Exception as e:
            print(f"Batch Render Utility: Failed to load profiles from single file: {e}")

    cmd_file = os.path.join(addon_dir, "json/command_line.json")
    if os.path.exists(cmd_file):
        try:
            with open(cmd_file, 'r') as f:
                data = json.load(f)
                wm.batch_render_output_path = data.get("path", "")
        except Exception as e:
            pass

    State.is_loading_profiles = False

def save_profiles_to_disk(wm):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    profiles_file = os.path.join(addon_dir, "json/output_profiles.json")
    
    data = []
    for p in wm.batch_output_profiles:
        data.append({
            "name": p.name,
            "settings_json": p.settings_json
        })
        
    try:
        with open(profiles_file, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"Batch Render Utility: Failed to save profiles to single file: {e}")

def save_command_line_path(self, context):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    cmd_file = os.path.join(addon_dir, "json/command_line.json")
    data = {"path": self.batch_render_output_path}
    try:
        with open(cmd_file, 'w') as f:
            json.dump(data, f, indent=4)
    except Exception:
        pass

def update_profile_name(self, context):
    if State.is_loading_profiles: return
    if hasattr(context, "window_manager"):
        save_profiles_to_disk(context.window_manager)

class RENDER_OT_batch_notify_msg(bpy.types.Operator):
    bl_idname = "render.batch_notify_msg"
    bl_label = "Batch Notification"
    bl_description = "Show a notification for batch render"

    message: StringProperty(default="")
    level: StringProperty(default="INFO")

    def execute(self, context):
        self.report({self.level}, self.message)
        return {'FINISHED'}

class RENDER_OT_batch_add_token(bpy.types.Operator):
    bl_idname = "render.batch_add_token"
    bl_label = "Add to All"
    bl_description = "Append scene token subdirectories to ALL paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        count = 0
        for scene in bpy.data.scenes:
            path = scene.render.filepath
            if not any(path.endswith(v) for v in VARIANTS):
                base_path = path.rstrip("\\/")
                scene.render.filepath = f"{base_path}{TOKEN}"
                count += 1
        self.report({'INFO'}, f"Added tokens to {count} scene(s)")
        return {'FINISHED'}

class RENDER_OT_batch_remove_token(bpy.types.Operator):
    bl_idname = "render.batch_remove_token"
    bl_label = "Remove from All"
    bl_description = "Strip scene token subdirectories from ALL paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        count = 0
        for scene in bpy.data.scenes:
            path = scene.render.filepath
            for variant in VARIANTS:
                if path.endswith(variant):
                    scene.render.filepath = path[:-len(variant)]
                    count += 1
                    break
        self.report({'INFO'}, f"Reverted paths for {count} scene(s)")
        return {'FINISHED'}

class RENDER_OT_toggle_scene_token(bpy.types.Operator):
    bl_idname = "render.toggle_scene_token"
    bl_label = "Toggle Token"
    bl_description = "Add or remove the token for this specific scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    scene_name: StringProperty()
    
    def execute(self, context):
        if self.scene_name not in bpy.data.scenes:
            return {'CANCELLED'}
            
        scene = bpy.data.scenes[self.scene_name]
        path = scene.render.filepath
        has_token = False
        
        for variant in VARIANTS:
            if path.endswith(variant):
                scene.render.filepath = path[:-len(variant)]
                has_token = True
                break
        
        if not has_token:
            base_path = path.rstrip("\\/")
            scene.render.filepath = f"{base_path}{TOKEN}"
            
        return {'FINISHED'}

class RENDER_OT_execute_batch_queue(bpy.types.Operator):
    bl_idname = "render.execute_batch_queue"
    bl_label = "Render Selected"
    bl_description = "Render all checked scenes"

    is_animation: BoolProperty(default=False)

    def execute(self, context):
        wm = context.window_manager
        render_mode = wm.batch_render_mode

        queued_scenes = [s for s in bpy.data.scenes if s.batch_token_queue]

        if len(queued_scenes) == 0 and render_mode != 'PROJECT':
            self.report({'WARNING'}, "No scenes queued for rendering!")
            return {'CANCELLED'}

        # -----------------------------------------------------------------
        # COMMAND LINE MODE
        # -----------------------------------------------------------------

        if render_mode == 'COMMAND_LINE':

            if not bpy.data.is_saved:
                self.report({'ERROR'}, "Please save your blend file first.")
                return {'CANCELLED'}

            bpy.ops.wm.save_mainfile()

            blender_exec = bpy.app.binary_path
            filepath = bpy.data.filepath

            cmds = []
            scenes_str = ",".join(s.name for s in queued_scenes)

            cmd = [blender_exec, "-b", "--factory-startup", filepath]
            
            is_anim_str = "True" if self.is_animation else "False"
            py_code = """import bpy, datetime, os, shutil, re, glob, random
d_str = datetime.datetime.now().strftime('%d%m%y')
for s in bpy.data.scenes:
    op = s.render.filepath
    if any(t in op for t in ['{{scene}}', '{{camera}}', '{{date}}', '{{frame_range}}']):
        s.render.filepath = op.replace('{{scene}}', s.name).replace('{{camera}}', s.camera.name if getattr(s, 'camera', None) else 'NoCamera').replace('{{date}}', d_str).replace('{{frame_range}}', f'{s.frame_start}-{s.frame_end}')
    if any(t in op for t in ['[s]', '[d]', '[c]', '[f]', '[e]']):
        s.render.filepath = op.replace('[f]', s.name + '/').replace('[s]', s.name).replace('[c]', s.camera.name if getattr(s, 'camera', None) else 'NoCamera').replace('[d]', d_str).replace('[e]', '')
is_anim = {IS_ANIM}

def post_comp(scene):
    if '#' in scene.render.filepath: return
    wanted = bpy.path.abspath(scene.render.filepath)
    if wanted.endswith('/') or wanted.endswith('\\\\'): return
    is_movie = scene.render.image_settings.file_format in {'FFMPEG', 'AVI_JPEG', 'AVI_RAW'}
    if is_anim and not is_movie: return
    try:
        ext = scene.render.file_extension
        dest = wanted if wanted.endswith(ext) else wanted + ext
        search_pattern = wanted + '*' + ext
        written = None
        for m in glob.glob(search_pattern):
            if re.match('^' + re.escape(wanted) + r'\\d*(-\\d+)?' + re.escape(ext) + '$', m):
                written = m
                break
        if written and os.path.exists(written) and os.path.abspath(written) != os.path.abspath(dest):
            if os.path.exists(dest): os.remove(dest)
            shutil.move(written, dest)
    except: pass
bpy.app.handlers.render_complete.append(post_comp)
            """.replace('{IS_ANIM}', is_anim_str)
            
            import base64
            b64_code = base64.b64encode(py_code.encode('utf-8')).decode('utf-8')
            expr = f"exec(__import__('base64').b64decode('{b64_code}').decode('utf-8'))"
            cmd.extend(["--python-expr", expr])
            
            for scene in queued_scenes:
                cmd.extend(["-S", scene.name])
                if self.is_animation:
                    cmd.append("-a")
                else:
                    cmd.extend(["-f", str(scene.frame_current)])
            cmds.append(cmd)

            addon_dir = os.path.dirname(os.path.abspath(__file__))
            wrapper_path = os.path.join(addon_dir, "wrapper_template.py")
            
            py_exe = os.path.join(sys.prefix, 'bin', 'python.exe' if sys.platform == 'win32' else 'python3')
            if not os.path.exists(py_exe):
                py_exe = 'python' if sys.platform == 'win32' else 'python3'

            try:
                # WINDOWS
                if sys.platform == 'win32':

                    sound_path = os.path.join(addon_dir, "render_success.ogg")

                    with tempfile.NamedTemporaryFile(mode='w', suffix='.bat', delete=False) as f:
                        f.write("@echo off\n")
                        f.write("echo Batch Render Utility\n")
                        for cmd in cmds:
                            args = [py_exe, wrapper_path, blender_exec, filepath, scenes_str] + cmd
                            cmd_str = subprocess.list2cmdline(args)
                            f.write(f"{cmd_str}\n")
                        f.write(f"powershell -c \"$player = New-Object -ComObject wmplayer.ocx; $player.URL = '{sound_path}'; $player.controls.play(); Start-Sleep -s 5\"\n")
                        f.write("pause\n")
                        bat_path = f.name

                    custom_exe = ""
                    if hasattr(wm, 'batch_render_output_path') and wm.batch_render_output_path:
                        custom_path = bpy.path.abspath(wm.batch_render_output_path).replace('//', '')
                        if custom_path and os.path.exists(custom_path) and os.path.isfile(custom_path):
                            custom_exe = os.path.normpath(custom_path)

                    if custom_exe:
                        subprocess.Popen(['cmd.exe', '/c', 'start', 'Batch Render', custom_exe, '/c', bat_path])
                    else:
                        cmd_exe_path = r"C:\Windows\System32\cmd.exe"
                        
                        if os.path.exists(cmd_exe_path):
                            subprocess.Popen(['cmd.exe', '/c', 'start', 'Batch Render', cmd_exe_path, '/c', bat_path])
                        else:
                            subprocess.Popen([
                                'cmd.exe',
                                '/c',
                                'start',
                                'Batch Render',
                                bat_path
                            ])

                # MACOS
                elif sys.platform == 'darwin':

                    sound_path = os.path.join(addon_dir, "render_success.ogg")

                    with tempfile.NamedTemporaryFile(mode='w', suffix='.command', delete=False) as f:
                        f.write("#!/bin/bash\n")
                        for cmd in cmds:
                            args = [py_exe, wrapper_path, blender_exec, filepath, scenes_str] + cmd
                            cmd_str = ' '.join(shlex.quote(c) for c in args)
                            f.write(f"{cmd_str}\n")
                        f.write(f"afplay {shlex.quote(sound_path)}\n")
                        f.write("echo 'Batch render complete.'\n")
                        f.write("read -p 'Press Enter to close...'\n")
                        script_path = f.name

                    os.chmod(script_path, 0o755)
                    custom_exe = ""
                    if hasattr(wm, 'batch_render_output_path') and wm.batch_render_output_path:
                        custom_path = bpy.path.abspath(wm.batch_render_output_path).replace('//', '')
                        if custom_path and os.path.exists(custom_path) and os.path.isfile(custom_path):
                            custom_exe = custom_path
                            
                    if custom_exe:
                        subprocess.Popen(['open', '-a', custom_exe, script_path])
                    else:
                        subprocess.Popen(['open', script_path])

                # LINUX
                else:

                    sound_path = os.path.join(addon_dir, "render_success.ogg")

                    with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as f:
                        f.write("#!/bin/bash\n")
                        for cmd in cmds:
                            args = [py_exe, wrapper_path, blender_exec, filepath, scenes_str] + cmd
                            cmd_str = ' '.join(shlex.quote(c) for c in args)
                            f.write(f"{cmd_str}\n")
                        f.write(f"test -x /usr/bin/paplay && paplay {shlex.quote(sound_path)} || aplay {shlex.quote(sound_path)}\n")
                        f.write("echo 'Batch render complete.'\n")
                        f.write("read -p 'Press Enter to close...'\n")
                        script_path = f.name

                    os.chmod(script_path, 0o755)

                    terminals = [
                        'x-terminal-emulator',
                        'gnome-terminal',
                        'konsole',
                        'xfce4-terminal'
                    ]

                    term_cmd = None

                    for term in terminals:
                        if shutil.which(term):
                            if term == 'gnome-terminal':
                                term_cmd = [term, '--', 'bash', script_path]
                            else:
                                term_cmd = [term, '-e', script_path]
                            break

                    custom_exe = ""
                    if hasattr(wm, 'batch_render_output_path') and wm.batch_render_output_path:
                        custom_path = bpy.path.abspath(wm.batch_render_output_path).replace('//', '')
                        if custom_path and os.path.exists(custom_path) and os.path.isfile(custom_path):
                            custom_exe = custom_path

                    if custom_exe:
                        subprocess.Popen([custom_exe, '-e', script_path])
                    elif term_cmd:
                        subprocess.Popen(term_cmd)
                    else:
                        subprocess.Popen(['bash', script_path])

                msg = "entire project" if render_mode == 'PROJECT' else f"{len(queued_scenes)} scenes"
                self.report({'INFO'}, f"Started {render_mode} render for {msg}.")

            except Exception as e:
                self.report({'ERROR'}, f"Failed to start render process: {str(e)}")
                return {'CANCELLED'}

            return {'FINISHED'}

        # -----------------------------------------------------------------
        # PROJECT MODE
        # -----------------------------------------------------------------

                        
        if State.batch_render_running:
            self.report({'WARNING'}, "Batch render already running.")
            return {'CANCELLED'}

        State.batch_render_queue = [scene.name for scene in queued_scenes]
        State.batch_render_animation = self.is_animation
        State.batch_render_running = True

        bpy.app.timers.register(batch_render_next_scene, first_interval=0.5)

        self.report({'INFO'}, f"Started project render for {len(queued_scenes)} scenes.")

        return {'FINISHED'}

# --- UIList Class for the Token Menu ---
class RENDER_UL_token_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = item
        row = layout.row(align=True)
        
        split = row.split(factor=0.7)
        split.label(text=scene.name)
        
        row_right = split.row(align=True)
        path = scene.render.filepath
        has_token = any(path.endswith(v) for v in VARIANTS)
        
        if has_token:
            op = row_right.operator("render.toggle_scene_token", text="", icon='X')
        else:
            op = row_right.operator("render.toggle_scene_token", text="", icon='ADD')
            
        op.scene_name = scene.name

# --- UIList Class for the Queue Menu ---
class RENDER_UL_scene_queue_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = item
        row = layout.row(align=True)
        
        # 1. The Checkbox
        row.prop(scene, "batch_token_queue", text="")
        
        # Split layout to allocate space for name vs fields cleanly
        split = row.split(factor=0.4)
        
        # 2. The Scene Name
        split.label(text=scene.name)
        
        # Right side layout
        row_right = split.row(align=True)
        
        # 3. Start & End Frames
        row_right.prop(scene, "frame_start", text="")
        row_right.prop(scene, "frame_end", text="")

class RENDER_UL_improved_scene_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = item
        row = layout.row(align=True)
        row.label(text=scene.name)
        row.prop(scene, "batch_token_queue", text="")

class RENDER_OT_batch_push_improved_template(bpy.types.Operator):
    bl_idname = "render.batch_push_improved_template"
    bl_label = "PUSH"
    bl_description = "Apply the new file path template to all ticked scenes"
    
    def execute(self, context):
        wm = context.window_manager
        template = wm.batch_improved_template
        
        order = ["[f]", "[s]", "[d]", "[c]", "[e]"]
        
        last_index = -1
        is_valid = True
        
        for tag in order:
            idx = template.find(tag)
            if idx != -1:
                if idx < last_index:
                    is_valid = False
                    break
                last_index = idx

        if not is_valid:
            self.report({'ERROR'}, "Template tags are out of order! Expected order: [f][s][d][c][e]")
            wm.batch_improved_template_error = True
            return {'CANCELLED'}
        else:
            wm.batch_improved_template_error = False

        import datetime
        now_date = datetime.datetime.now().strftime("%d%m%y")

        for scene in bpy.data.scenes:
            if scene.batch_token_queue:
                if "[e]" in template:
                    scene.render.use_file_extension = False
                
                parsed = template
                parsed = parsed.replace("[f]", f"{scene.name}/")
                parsed = parsed.replace("[s]", scene.name)
                parsed = parsed.replace("[d]", now_date)
                cam_name = scene.camera.name if scene.camera else "NoCamera"
                parsed = parsed.replace("[c]", cam_name)
                
                ext = ""
                try:
                    media_type = scene.render.image_settings.media_type
                    if media_type == 'VIDEO':
                        fmt = scene.render.ffmpeg.format
                        if fmt == 'MPEG4': ext = ".mp4"
                        elif fmt == 'MKV': ext = ".mkv"
                        elif fmt == 'WEBM': ext = ".webm"
                        elif fmt == 'AVI': ext = ".avi"
                        elif fmt == 'DV': ext = ".dv"
                        elif fmt == 'FLASH': ext = ".flv"
                        elif fmt == 'MPEG1': ext = ".mpg"
                        elif fmt == 'MPEG2': ext = ".dvd"
                        elif fmt == 'OGG': ext = ".ogg"
                        elif fmt == 'QUICKTIME': ext = ".mov"
                        else: ext = scene.render.file_extension if hasattr(scene.render, "file_extension") else ".mp4"
                    else:
                        fmt = scene.render.image_settings.file_format
                        if fmt == 'PNG': ext = ".png"
                        elif fmt == 'JPEG': ext = ".jpg"
                        elif fmt == 'BMP': ext = ".bmp"
                        elif fmt == 'OPEN_EXR': ext = ".exr"
                        elif fmt == 'OPEN_EXR_MULTILAYER': ext = ".exr"
                        elif fmt == 'TARGA' or fmt == 'TARGA_RAW': ext = ".tga"
                        elif fmt == 'TIFF': ext = ".tif"
                        elif fmt == 'JPEG2000': ext = ".jp2"
                        elif fmt == 'CINEON': ext = ".cin"
                        elif fmt == 'DPX': ext = ".dpx"
                        elif fmt == 'WEBP': ext = ".webp"
                        elif fmt == 'HDR': ext = ".hdr"
                        elif fmt == 'IRIS': ext = ".rgb"
                        else: ext = scene.render.file_extension if hasattr(scene.render, "file_extension") else ""
                except Exception:
                    ext = scene.render.file_extension if hasattr(scene.render, "file_extension") else ""
                    
                parsed = parsed.replace("[e]", ext)
                
                prefix = getattr(wm, "batch_improved_prefix", "")
                scene.render.filepath = prefix + parsed
                
        self.report({'INFO'}, "Pushed improved template to selected scenes")
        return {'FINISHED'}

class RENDER_PT_token_panel(bpy.types.Panel):
    bl_label = "Blender Render Tokens"
    bl_idname = "RENDER_PT_token_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch' 

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        layout.prop(wm, "batch_token_mode", expand=True)
        layout.separator()
        
        if wm.batch_token_mode == 'LEGACY':
            box_global = layout.box()
            box_global.label(text="Global Token Assignment:", icon='WORLD')
            row_global = box_global.row(align=True)
            row_global.operator("render.batch_add_token", icon='ADD')
            row_global.operator("render.batch_remove_token", icon='REMOVE')
    
            layout.separator()
            layout.label(text="Scene Tokens:", icon='TEXT')
            layout.template_list(
                "RENDER_UL_token_list", 
                "", 
                bpy.data, 
                "scenes", 
                wm, 
                "batch_token_list_index"
            )
        elif wm.batch_token_mode == 'IMPROVED':
            layout.label(text="Select Scenes:", icon='SCENE_DATA')
            layout.template_list(
                "RENDER_UL_improved_scene_list", 
                "", 
                bpy.data, 
                "scenes", 
                wm, 
                "batch_improved_list_index"
            )
            
            box = layout.box()
            box.label(text="Available Tags:", icon='INFO')
            col = box.column(align=True)
            col.label(text="[s] scene name in file name")
            col.label(text="[d] date in file name (ddmmyy)")
            col.label(text="[c] camera name in file name")
            col.label(text="[f] a new folder for the file rendered by the scene")
            col.label(text="[e] file extension specified by the specific scene output settings")
            
            layout.separator()
            layout.label(text="Prefix:")
            layout.prop(wm, "batch_improved_prefix", text="")
            
            layout.label(text='Example, follow format and order for best function: "[f][s][d][c][e]"')
            
            row = layout.row()
            if getattr(wm, "batch_improved_template_error", False):
                row.alert = True
            row.prop(wm, "batch_improved_template", text="")
            
            layout.operator("render.batch_push_improved_template", icon='FORWARD')

# --- PANEL 2: Render Queue and Lists ---
class RENDER_PT_queue_panel(bpy.types.Panel):
    bl_label = "Batch Render Queue"
    bl_idname = "RENDER_PT_queue_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch' 
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        # Individual Scene List
        layout.label(text="Scene Queue:", icon='VIEW_CAMERA')
        
        # The scrollable list rendering
        layout.template_list(
            "RENDER_UL_scene_queue_list", 
            "", 
            bpy.data, 
            "scenes", 
            context.window_manager, 
            "batch_list_index"
        )
            
        layout.separator()
        
        # -----------------------------------------------------------------
        # COMMAND LINE OUTPUT BOX
        # -----------------------------------------------------------------
        
        box_out = layout.box()
        box_out.label(text="Command Line Output Path (Executable Shortcut):", icon='FILE_FOLDER')
        box_out.prop(wm, "batch_render_output_path", text="")
        box_out.label(text="Provide a the shortcut for the command prompt executable of Windows/Mac/Linux.", icon='INFO')

        layout.separator()

        # -----------------------------------------------------------------
        # BATCH RENDER MODE
        # -----------------------------------------------------------------

        box_mode = layout.box()
        box_mode.label(text="Batch Render Mode:", icon='PREFERENCES')
        box_mode.prop(wm, "batch_render_mode", expand=True)

        # -----------------------------------------------------------------
        # EXECUTION BUTTONS
        # -----------------------------------------------------------------

        box_mode.separator()
        box_mode.label(text="Execute Render Queue / Project:", icon='RENDER_RESULT')
        row_exec = box_mode.row(align=True)
        
        op_still = row_exec.operator("render.execute_batch_queue", text="Stills", icon='RENDER_STILL')
        op_still.is_animation = False
        
        op_anim = row_exec.operator("render.execute_batch_queue", text="Animations", icon='RENDER_ANIMATION')
        op_anim.is_animation = True

# --- PROFILES AND SETTINGS SYNC ---
class RENDER_PG_output_profile(bpy.types.PropertyGroup):
    name: StringProperty(name="Profile Name", default="New Profile", update=update_profile_name)
    settings_json: StringProperty(name="Settings JSON", default="{}")
    file_id: StringProperty(name="File ID", default="")

class RENDER_UL_output_profile_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "name", text="", emboss=False, icon='PREFERENCES')

class RENDER_OT_profile_add(bpy.types.Operator):
    bl_idname = "render.profile_add"
    bl_label = "Save Output to Profile"
    bl_description = "Save the active scene's output settings as a new profile"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        new_profile = profiles.add()
        new_profile.name = f"Profile {len(profiles)}"
        import uuid
        new_profile.file_id = str(uuid.uuid4()) + ".json"
        
        dump = {}
        r = scene.render

        # Render dimensions / frame rate
        for k in ['resolution_x', 'resolution_y', 'resolution_percentage', 'fps', 'fps_base']:
            dump[k] = getattr(r, k)

        # Output section: path, saving flags, pixel density
        for k in ['filepath', 'use_file_extension', 'use_render_cache', 'dpi']:
            if hasattr(r, k):
                dump[k] = getattr(r, k)

        # Image / format settings
        i = r.image_settings
        if hasattr(i, 'media_type'):
            dump['img_media_type'] = getattr(i, 'media_type')
        elif hasattr(r, 'media_type'):
            dump['media_type'] = getattr(r, 'media_type')

        for k in ['file_format', 'color_mode', 'color_depth', 'compression', 'quality', 'exr_codec', 'tiff_codec', 'color_space']:
            if hasattr(i, k):
                dump['img_' + k] = getattr(i, k)
                
        # Better Color Space saving for Blender 4/5
        if hasattr(i, 'color_space_settings') and hasattr(i.color_space_settings, 'name'):
            dump['img_color_space'] = i.color_space_settings.name
                
        # FFMpeg settings
        if hasattr(r, 'ffmpeg'):
            ff = r.ffmpeg
            for k in ['format', 'use_autosplit', 'codec', 'video_profile', 'constant_rate_factor', 'audio_codec', 'video_bitrate', 'audio_bitrate']:
                if hasattr(ff, k):
                    dump['ff_' + k] = getattr(ff, k)

        new_profile.settings_json = json.dumps(dump)
        wm.batch_output_profile_index = len(profiles) - 1
        save_profiles_to_disk(wm)
        return {'FINISHED'}

class RENDER_OT_profile_remove(bpy.types.Operator):
    bl_idname = "render.profile_remove"
    bl_label = "Remove Selected Profile"
    bl_description = "Delete the currently selected output profile"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        idx = wm.batch_output_profile_index
        
        if 0 <= idx < len(profiles):
            profiles.remove(idx)
            wm.batch_output_profile_index = max(0, idx - 1)
            save_profiles_to_disk(wm)
        return {'FINISHED'}

def apply_profile_to_scene(profile, target_scene):
    try:
        dump = json.loads(profile.settings_json)
    except Exception:
        return
        
    r = target_scene.render
    i = r.image_settings
    
    # 1. Prerequisite setup: Media Type and File Format MUST be applied first
    if 'img_media_type' in dump and hasattr(i, 'media_type'):
        try: i.media_type = dump['img_media_type']
        except: pass
    if 'media_type' in dump and hasattr(r, 'media_type'):
        try: r.media_type = dump['media_type']
        except: pass

    if 'img_file_format' in dump:
        try:
            i.file_format = dump['img_file_format']
        except Exception as e:
            print(f"Batch Render Utility: Could not set file_format {dump['img_file_format']} - {e}")
            try:
                if hasattr(i, 'media_type'): i.media_type = 'VIDEO'
                elif hasattr(r, 'media_type'): r.media_type = 'VIDEO'
            except: pass
            try: i.file_format = 'FFMPEG'
            except: pass
            try: i.color_mode = 'RGBA'
            except: pass
            if hasattr(r, 'ffmpeg'):
                try: r.ffmpeg.format = 'QUICKTIME'
                except: pass
                try: r.ffmpeg.codec = 'PRORES'
                except: pass
                try: r.ffmpeg.video_profile = '4444'
                except: pass
        
    # Explicit ordered application of keys matching the UI top-to-bottom layout
    ordered_keys = [
        # Dimensions and Resolution
        'resolution_x', 'resolution_y', 'resolution_percentage', 'fps', 'fps_base',
        # Saving path and core toggles
        'filepath', 'use_file_extension', 'use_render_cache', 'dpi',
        # Media / Color Mode
        'img_color_mode',
        # Encoding / Container
        'ff_format', 'ff_use_autosplit', 
        # Video Codec
        'ff_codec', 
        # Video-specific Color Depth / Space
        'img_color_depth', 'img_color_space',
        # Codec encoding profile 
        'ff_video_profile', 
        # Compression and Quality settings
        'ff_constant_rate_factor', 'ff_video_bitrate',
        # Audio Codec and Audio settings
        'ff_audio_codec', 'ff_audio_bitrate',
        'img_compression', 'img_quality', 'img_exr_codec', 'img_tiff_codec'
    ]
    
    # First pass: apply properties strictly in our layout order
    for k in ordered_keys:
        if k in dump:
            v = dump[k]
            if k == 'img_color_space':
                if hasattr(i, 'color_space_settings') and hasattr(i.color_space_settings, 'name'):
                    try: i.color_space_settings.name = v
                    except Exception: pass
                elif hasattr(i, 'color_space'):
                    try: i.color_space = v
                    except Exception: pass
            elif k.startswith('img_'):
                prop_name = k[4:]
                if hasattr(i, prop_name):
                    try: setattr(i, prop_name, v)
                    except Exception: pass
            elif k.startswith('ff_'):
                prop_name = k[3:]
                if hasattr(r, 'ffmpeg') and hasattr(r.ffmpeg, prop_name):
                    try: setattr(r.ffmpeg, prop_name, v)
                    except Exception: pass
            else:
                if hasattr(r, k):
                    try: setattr(r, k, v)
                    except Exception: pass
                    
    # Second pass: fallback safety for any remaining elements
    for k, v in dump.items():
        if k in ordered_keys or k in ['img_media_type', 'media_type', 'img_file_format']:
            continue
            
        if k == 'img_color_space':
            if hasattr(i, 'color_space_settings') and hasattr(i.color_space_settings, 'name'):
                try: i.color_space_settings.name = v
                except Exception: pass
            elif hasattr(i, 'color_space'):
                try: i.color_space = v
                except Exception: pass
        elif k.startswith('img_'):
            prop_name = k[4:]
            if hasattr(i, prop_name):
                try: setattr(i, prop_name, v)
                except Exception: pass
        elif k.startswith('ff_'):
            prop_name = k[3:]
            if hasattr(r, 'ffmpeg') and hasattr(r.ffmpeg, prop_name):
                try: setattr(r.ffmpeg, prop_name, v)
                except Exception: pass
        else:
            if hasattr(r, k):
                try: setattr(r, k, v)
                except Exception: pass

class RENDER_OT_profile_apply(bpy.types.Operator):
    bl_idname = "render.profile_apply"
    bl_label = "Apply to Active Scene"
    bl_description = "Apply the selected profile's output settings to the active scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        idx = wm.batch_output_profile_index
        
        if 0 <= idx < len(profiles):
            apply_profile_to_scene(profiles[idx], scene)
            self.report({'INFO'}, f"Applied profile '{profiles[idx].name}' to {scene.name}")
        return {'FINISHED'}

class RENDER_OT_batch_sync_profile(bpy.types.Operator):
    bl_idname = "render.batch_sync_profile"
    bl_label = "Batch Sync Profile to ALL Scenes"
    bl_description = "Apply the selected profile's output settings to ALL scenes in the file"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        wm = context.window_manager
        profiles = wm.batch_output_profiles
        idx = wm.batch_output_profile_index
        
        if 0 <= idx < len(profiles):
            profile = profiles[idx]
            count = 0
            for s in bpy.data.scenes:
                apply_profile_to_scene(profile, s)
                count += 1
            self.report({'INFO'}, f"Applied profile '{profile.name}' to {count} scene(s)")
        return {'FINISHED'}

class RENDER_OT_batch_sync_active(bpy.types.Operator):
    bl_idname = "render.batch_sync_active"
    bl_label = "Sync Active to ALL Scenes"
    bl_description = "Copy the active scene's output settings to ALL scenes in the file"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        
        dump = {}
        r = scene.render
        for k in ['resolution_x', 'resolution_y', 'resolution_percentage', 'fps', 'fps_base']:
            dump[k] = getattr(r, k)

        # Output section: path, saving flags, pixel density
        for k in ['filepath', 'use_file_extension', 'use_render_cache', 'dpi']:
            if hasattr(r, k):
                dump[k] = getattr(r, k)

        i = r.image_settings
        if hasattr(i, 'media_type'):
            dump['img_media_type'] = getattr(i, 'media_type')
        elif hasattr(r, 'media_type'):
            dump['media_type'] = getattr(r, 'media_type')

        for k in ['file_format', 'color_mode', 'color_depth', 'compression', 'quality', 'exr_codec', 'tiff_codec', 'color_space']:
            if hasattr(i, k):
                dump['img_' + k] = getattr(i, k)
                
        if hasattr(r, 'ffmpeg'):
            ff = r.ffmpeg
            for k in ['format', 'use_autosplit', 'codec', 'video_profile', 'constant_rate_factor', 'audio_codec', 'video_bitrate', 'audio_bitrate']:
                if hasattr(ff, k):
                    dump['ff_' + k] = getattr(ff, k)

        count = 0
        
        class DummyProfile:
            pass
        tmp_profile = DummyProfile()
        tmp_profile.settings_json = json.dumps(dump)
        
        for s in bpy.data.scenes:
            if s == scene:
                continue
            
            apply_profile_to_scene(tmp_profile, s)
            count += 1
            
        self.report({'INFO'}, f"Synced output settings to {count} other scene(s)")
        return {'FINISHED'}

class RENDER_PT_sync_settings_panel(bpy.types.Panel):
    bl_label = "Batch Sync Output"
    bl_idname = "RENDER_PT_sync_settings_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch'
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        # 1. Sync Active to All
        layout.label(text="Sync Current Settings:", icon='FILE_REFRESH')
        layout.operator("render.batch_sync_active", icon='SCENE_DATA')

class RENDER_PT_sync_settings_profiles_panel(bpy.types.Panel):
    bl_label = "Output Profiles (WIP)"
    bl_idname = "RENDER_PT_sync_settings_profiles_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Batch'
    bl_parent_id = "RENDER_PT_sync_settings_panel"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        row = layout.row()
        row.template_list(
            "RENDER_UL_output_profile_list", 
            "", 
            wm, 
            "batch_output_profiles", 
            wm, 
            "batch_output_profile_index",
            rows=3
        )
        
        col = row.column(align=True)
        col.operator("render.profile_add", text="", icon='ADD')
        col.operator("render.profile_remove", text="", icon='REMOVE')
        
        if len(wm.batch_output_profiles) > 0:
            box = layout.box()
            box.label(text="Apply Selected Profile:", icon='CHECKBOX_HLT')
            box.operator("render.profile_apply", text="Apply to Active Scene", icon='SCENE_DATA')
            box.operator("render.batch_sync_profile", text="Sync to ALL Scenes", icon='MODIFIER_ON')

classes = (
    RENDER_OT_batch_add_token,
    RENDER_OT_batch_notify_msg,
    RENDER_OT_batch_remove_token,
    RENDER_OT_toggle_scene_token,
    RENDER_OT_batch_push_improved_template,
    RENDER_OT_execute_batch_queue,
    RENDER_UL_token_list,
    RENDER_UL_improved_scene_list,
    RENDER_UL_scene_queue_list,
    RENDER_PT_token_panel,
    RENDER_PT_queue_panel,
    RENDER_PG_output_profile,
    RENDER_UL_output_profile_list,
    RENDER_OT_profile_add,
    RENDER_OT_profile_remove,
    RENDER_OT_profile_apply,
    RENDER_OT_batch_sync_profile,
    RENDER_OT_batch_sync_active,
    RENDER_PT_sync_settings_panel,
    RENDER_PT_sync_settings_profiles_panel,
)

def init_profiles():
    if hasattr(bpy.context, "window_manager") and bpy.context.window_manager:
        load_profiles_from_disk(bpy.context.window_manager)
        
        addon_dir = os.path.dirname(os.path.abspath(__file__))
        json_dir = os.path.join(addon_dir, "json")
        
        # Cleanup old legacy json files if they exist
        old_files = ["scene_tags.json", "camera_tags.json", "date_tags.json", "frame_range_tags.json", "folder_tags.json"]
        for old_file in old_files:
            p = os.path.join(json_dir, old_file)
            if os.path.exists(p):
                try:
                    os.remove(p)
                except:
                    pass
        
        # Load improved template from bbr_tags.json
        p_tags_file = os.path.join(json_dir, "bbr_tags.json")
        if os.path.exists(p_tags_file):
            try:
                with open(p_tags_file, 'r') as f:
                    data = json.load(f)
                blend_path = bpy.data.filepath or "unsaved_project.blend"
                if blend_path in data:
                    bpy.context.window_manager.batch_improved_template = data[blend_path].get("template", "")
            except:
                pass
                
        # Load prefix from prefix_filepath.json
        prefix_file = os.path.join(json_dir, "prefix_filepath.json")
        if os.path.exists(prefix_file):
            try:
                with open(prefix_file, 'r') as f:
                    data = json.load(f)
                blend_path = bpy.data.filepath or "unsaved_project.blend"
                if blend_path in data:
                    bpy.context.window_manager.batch_improved_prefix = data[blend_path].get("prefix", "")
            except:
                pass
    return None

@bpy.app.handlers.persistent
def on_blend_load(dummy):
    if not bpy.app.timers.is_registered(init_profiles):
        bpy.app.timers.register(init_profiles, first_interval=0.1)

def update_scene_index(self, context):
    try:
        idx = self.batch_list_index
        if 0 <= idx < len(bpy.data.scenes):
            tgt_scene = bpy.data.scenes[idx]
            if context.window.scene != tgt_scene:
                context.window.scene = tgt_scene
    except Exception:
        pass

def update_scene_token_index(self, context):
    try:
        idx = self.batch_token_list_index
        if 0 <= idx < len(bpy.data.scenes):
            tgt_scene = bpy.data.scenes[idx]
            if context.window.scene != tgt_scene:
                context.window.scene = tgt_scene
    except Exception:
        pass

def update_improved_scene_index(self, context):
    try:
        idx = self.batch_improved_list_index
        if 0 <= idx < len(bpy.data.scenes):
            tgt_scene = bpy.data.scenes[idx]
            if context.window.scene != tgt_scene:
                context.window.scene = tgt_scene
    except Exception:
        pass

def update_token_mode(self, context):
    pass

def update_improved_prefix(self, context):
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    json_dir = os.path.join(addon_dir, "json")
    if not os.path.exists(json_dir):
        os.makedirs(json_dir, exist_ok=True)
    prefix_file = os.path.join(json_dir, "prefix_filepath.json")
    data = {}
    if os.path.exists(prefix_file):
        try:
            with open(prefix_file, 'r') as f:
                data = json.load(f)
        except:
            pass
    blend_path = bpy.data.filepath or "unsaved_project.blend"
    data[blend_path] = {"prefix": self.batch_improved_prefix}
    try:
        with open(prefix_file, 'w') as f:
            json.dump(data, f, indent=4)
    except:
        pass

def update_improved_template(self, context):
    self.batch_improved_template_error = False
    addon_dir = os.path.dirname(os.path.abspath(__file__))
    json_dir = os.path.join(addon_dir, "json")
    if not os.path.exists(json_dir):
        os.makedirs(json_dir, exist_ok=True)
    p_tags_file = os.path.join(json_dir, "bbr_tags.json")
    data = {}
    if os.path.exists(p_tags_file):
        try:
            with open(p_tags_file, 'r') as f:
                data = json.load(f)
        except:
            pass
    blend_path = bpy.data.filepath or "unsaved_project.blend"
    data[blend_path] = {"template": self.batch_improved_template}
    try:
        with open(p_tags_file, 'w') as f:
            json.dump(data, f, indent=4)
    except:
        pass

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
    if on_blend_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(on_blend_load)
        
    if batch_render_complete_handler not in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.append(batch_render_complete_handler)
    if batch_render_cancel_handler not in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.append(batch_render_cancel_handler)
    if not bpy.app.timers.is_registered(init_profiles):
        bpy.app.timers.register(init_profiles, first_interval=0.1)

    # Scene properties
    bpy.types.Scene.batch_token_queue = bpy.props.BoolProperty(
        name="Queue",
        description="Include this scene in the batch render execution",
        default=False
    )
    
    # UI List tracking properties
    bpy.types.WindowManager.batch_list_index = bpy.props.IntProperty(
        name="Active List Index", 
        default=0,
        update=update_scene_index
    )
    bpy.types.WindowManager.batch_token_list_index = bpy.props.IntProperty(
        name="Active Token List Index", 
        default=0,
        update=update_scene_token_index
    )
    bpy.types.WindowManager.batch_improved_list_index = bpy.props.IntProperty(
        name="Improved Token List Index",
        default=0,
        update=update_improved_scene_index
    )
    bpy.types.WindowManager.batch_improved_prefix = bpy.props.StringProperty(
        name="",
        description="Prefix File Path",
        default="",
        update=update_improved_prefix
    )
    bpy.types.WindowManager.batch_improved_template = bpy.props.StringProperty(
        name="",
        description="Path Template",
        default="",
        update=update_improved_template
    )
    bpy.types.WindowManager.batch_improved_template_error = bpy.props.BoolProperty(
        default=False
    )
    bpy.types.WindowManager.batch_output_profiles = bpy.props.CollectionProperty(type=RENDER_PG_output_profile)
    bpy.types.WindowManager.batch_output_profile_index = bpy.props.IntProperty(name="Active Profile Index", default=0)

    # -----------------------------------------------------------------
    # TOKEN MODE TOGGLE
    # -----------------------------------------------------------------
    bpy.types.WindowManager.batch_token_mode = bpy.props.EnumProperty(
        name="Naming Scheme",
        description="Toggle between legacy and improved token naming schemes",
        items=[
            ('LEGACY', 'Legacy', 'Legacy output path'),
            ('IMPROVED', 'Improved', 'New naming scheme with dynamic tags')
        ],
        default='LEGACY',
        update=update_token_mode
    )

    # -----------------------------------------------------------------
    # COMMAND LINE OUTPUT BOX
    # -----------------------------------------------------------------
    bpy.types.WindowManager.batch_render_output_path = bpy.props.StringProperty(
        name="Terminal Executable Shortcut",
        description="Provide the shortcut for the command prompt executable. Leave empty to use system default",
        subtype='FILE_PATH',
        default="",
        update=save_command_line_path
    )

    # -----------------------------------------------------------------
    # RENDER MODE TOGGLE
    # -----------------------------------------------------------------
    bpy.types.WindowManager.batch_render_mode = bpy.props.EnumProperty(
        name="Render Mode",
        description="Choose how the batch queue should render",
        items=[
            ('COMMAND_LINE', 'Command Line', 'Render via Background Process'),
            ('PROJECT', 'Project', 'Render sequentially inside Blender')
        ],
        default='COMMAND_LINE'
    )

def unregister():
    if on_blend_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(on_blend_load)
        
    if batch_render_complete_handler in bpy.app.handlers.render_complete:
        bpy.app.handlers.render_complete.remove(batch_render_complete_handler)
    if batch_render_cancel_handler in bpy.app.handlers.render_cancel:
        bpy.app.handlers.render_cancel.remove(batch_render_cancel_handler)
    if bpy.app.timers.is_registered(init_profiles):
        bpy.app.timers.unregister(init_profiles)

    # Clean up properties
    del bpy.types.Scene.batch_token_queue
    
    del bpy.types.WindowManager.batch_list_index
    del bpy.types.WindowManager.batch_token_list_index
    del bpy.types.WindowManager.batch_improved_list_index
    del bpy.types.WindowManager.batch_improved_prefix
    del bpy.types.WindowManager.batch_improved_template
    del bpy.types.WindowManager.batch_improved_template_error
    del bpy.types.WindowManager.batch_output_profiles
    del bpy.types.WindowManager.batch_output_profile_index
    del bpy.types.WindowManager.batch_render_output_path
    del bpy.types.WindowManager.batch_render_mode
    del bpy.types.WindowManager.batch_token_mode
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
