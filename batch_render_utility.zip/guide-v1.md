###### Hi.



I hope you did the right thing by paying for this software. If you didn't, realise that you are most likely

using a version with a virus or some sort of sketchy code- though it was not the developer.



By proceeding to use this software you confirm that:



* **This plugin has access to your Windows/Mac/Linux command executable for rendering scenes.**
* Any viruses or damages that effect your computer as a result of **YOU** installing this software and

&#x09;running it is not my fault and thus I am not liable.

* Even if you did not pay for this plugin, I hope you know you are not doing the right thing by not

&#x09;choosing to support it. Even then, I hope you enjoy this plugin to the fullest of your ability.

&#x09;Please reconsider buying this as the purchase will fund this project for years to come.



**For further help with this software, do yourself a favor and visit the GitHub:**

**https://github.com/DThil-Dev/Batch-Render-Token-Utility/tree/main**

